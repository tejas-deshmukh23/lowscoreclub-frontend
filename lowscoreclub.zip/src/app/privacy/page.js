import React from 'react'
import PrivacyPolicy from '@/Components/PrivacyPolicy'

const page = () => {
  return (
    <>
    
    <PrivacyPolicy/>

    </>
  )
}

export default page