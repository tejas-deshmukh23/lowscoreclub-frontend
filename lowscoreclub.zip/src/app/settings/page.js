import React from 'react'
import SettingsPage from '@/Components/SettingsPage'

const page = () => {
  return (
    <>
        <SettingsPage/>
    </>
  )
}

export default page