import React from 'react'
import NotificationSender from "@/Components/NotificationSender"

const page = () => {
  return (
    <>
    <NotificationSender/>
    </>
  )
}

export default page