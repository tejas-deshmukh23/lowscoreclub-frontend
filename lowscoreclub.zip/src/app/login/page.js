import React from 'react'
import Login from "../../Components/login/login";

const login = () => {
  return (
    <>
        <Login/>
    </>
  )
}

export default login