"use client"
import React from 'react'
import HomePage from "../../Components/LowScoreClubPages/HomePage";
// import Layout from "../../Components/Layout";
// import RootLayout from "../layout";

const Page = () => {
  return (
    <>
        <HomePage/>
        {/* <RootLayout> */}
        {/* Render the actual page component */}
        {/* <Component {...pageProps} /> */}
      {/* </RootLayout> */}
    </>
  )
}

export default Page