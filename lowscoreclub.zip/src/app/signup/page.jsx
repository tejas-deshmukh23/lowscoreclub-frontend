import React from 'react'
import Signup from '@/Components/Signup/Signup'

const page = () => {
  return (
    <>
        <Signup/>
    </>
  )
}

export default page